<?php
get_sidebar('shop'); 
?>
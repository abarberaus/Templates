jQuery(document).ready(function($) {
	$(".tabs").tabs({ fx: { opacity: 'toggle', duration: 'fast' } });
});
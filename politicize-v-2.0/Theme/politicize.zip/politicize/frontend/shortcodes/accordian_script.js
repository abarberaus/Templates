jQuery(document).ready(function($) {
    $(".accordion_cp").accordion({
		collapsible: true
	});
});